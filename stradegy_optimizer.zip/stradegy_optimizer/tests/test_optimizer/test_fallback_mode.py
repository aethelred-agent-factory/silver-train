# tests/test_optimizer/test_fallback_mode.py
import pytest
import random
from src.optimizer.fallback_mode import FallbackMode
from src.backtesting.backtest_engine import BacktestEngine # Needs to be mocked

@pytest.fixture
def mock_backtest_engine(mocker):
    mock = mocker.Mock(spec=BacktestEngine)
    mock.rapid_backtest.return_value.profit_factor = 1.2
    mock.rapid_backtest.return_value.max_drawdown_pct = 10.0
    return mock

@pytest.fixture
def fallback_mode(test_config, mock_backtest_engine):
    # Set a fixed seed for reproducible random choices in tests
    random.seed(42)
    return FallbackMode(test_config, mock_backtest_engine)

def test_perturb_parameters(fallback_mode, mock_backtest_engine, mocker):
    current_params = {
        "min_score": 2.0,
        "rsi_oversold": 30,
        "stop_multiplier": 2.0,
        "risk_pct": 0.5,
        "w_range": 0.33,
        "w_rsi": 0.33,
        "w_trend": 0.34,
        "base_scale": 2.0
    }
    
    # Mock random.random to return specific values for predictable "scoring"
    # This makes sure the "best variant" is chosen deterministically
    mock_random = pytest.MonkeyPatch()
    mock_random.setattr(random, 'random', lambda: 0.8) # Always choose plus variant for simplicity in test
    
    # Temporarily set a mock return for rapid_backtest
    mock_backtest_engine.rapid_backtest.return_value = mocker.Mock(profit_factor=1.5, max_drawdown_pct=5.0)

    perturbed_params = fallback_mode.perturb_parameters(current_params, "BTC/USDT", "2023-01-01T00:00:00Z")
    
    assert isinstance(perturbed_params, dict)
    assert perturbed_params != current_params # Parameters should have changed
    
    # Example check (based on the mocked random score, 'plus' variant should be chosen for one param)
    # With random.seed(42), 'w_trend' is chosen. If random.random() returns 0.8, then 'plus' variant is chosen.
    expected_w_trend_min = fallback_mode.parameter_bounds['w_trend']['min']
    expected_w_trend_max = fallback_mode.parameter_bounds['w_trend']['max']
    expected_delta = 0.05 * (expected_w_trend_max - expected_w_trend_min)
    
    assert perturbed_params['w_trend'] == current_params['w_trend'] + expected_delta

def test_revert_to_safe_baseline(fallback_mode):
    safe_params = fallback_mode.revert_to_safe_baseline()
    assert safe_params == fallback_mode.config['safe_baseline']
