# tests/test_audit/test_audit_layer.py
import pytest
from datetime import datetime, timezone
from src.audit.audit_layer import AuditLayer
from src.data_bus.event_bus import EventBus
from src.data_bus.schemas import OptimizerProposal, AuditVerdict, TieredFinding, AuditAction
from src.audit.t1_checks import T1Checks
from src.audit.t2_checks import T2Checks
from src.audit.t3_checks import T3Checks
from src.audit.causal_chain_validator import CausalChainValidator
from src.audit.artifact_store import ArtifactStore

@pytest.fixture
def mock_t1_checks(mocker):
    mock = mocker.Mock(spec=T1Checks)
    mock.run_all.return_value = []
    return mock

@pytest.fixture
def mock_t2_checks(mocker):
    mock = mocker.Mock(spec=T2Checks)
    mock.run_all.return_value = []
    return mock

@pytest.fixture
def mock_t3_checks(mocker):
    mock = mocker.Mock(spec=T3Checks)
    mock.run_all.return_value = []
    return mock

@pytest.fixture
def mock_causal_validator(mocker):
    mock = mocker.Mock(spec=CausalChainValidator)
    mock.validate_proposal = mocker.Mock(return_value=True)
    return mock

@pytest.fixture
def mock_artifact_store(mocker):
    mock = mocker.Mock(spec=ArtifactStore)
    mock.store_artifact.return_value = AuditVerdict(
        audit_id="test_audit_id",
        proposal_id="test_proposal_id",
        timestamp=datetime.now(timezone.utc),
        tiered_findings=[],
        action=AuditAction(type="ALLOW"),
        artifact_refs=[],
        checksum="dummy_checksum"
    )
    mock.get_artifact_uri.return_value = "file:///path/to/artifact_id_123"
    return mock

@pytest.fixture
def event_bus_audit(in_memory_state_manager):
    return EventBus(in_memory_state_manager)

@pytest.fixture
def audit_layer(test_config, event_bus_audit, mock_t1_checks, mock_t2_checks, mock_t3_checks, mock_causal_validator, mock_artifact_store):
    return AuditLayer(test_config, event_bus_audit, mock_t1_checks, mock_t2_checks, mock_t3_checks, mock_causal_validator, mock_artifact_store)

@pytest.fixture
def sample_proposal():
    return OptimizerProposal(
        proposal_version=1,
        source="test_optimizer",
        proposed_parameters={"param1": 1.0},
        context={"regime_label": "RANGE", "metrics_snapshot": {"atr_percentile_90": 0.5}},
        causal_chain_refs=[]
    )

def test_audit_proposal_allow(audit_layer, event_bus_audit, sample_proposal):
    verdict = audit_layer.audit_proposal(sample_proposal)
    
    assert isinstance(verdict, AuditVerdict)
    assert verdict.action.type == "ALLOW"
    assert not verdict.tiered_findings
    
    # Check if verdict was published
    published_verdict = event_bus_audit.subscribe_verdict()
    assert published_verdict == verdict

def test_audit_proposal_block_t1(audit_layer, event_bus_audit, mock_t1_checks, sample_proposal):
    mock_t1_checks.run_all.return_value = [
        TieredFinding(tier="T1", code="T1_Contradiction", explanation="Contradiction found")
    ]
    
    verdict = audit_layer.audit_proposal(sample_proposal)
    
    assert isinstance(verdict, AuditVerdict)
    assert verdict.action.type == "BLOCK"
    assert verdict.action.restrictions['reason'] == "T1_Contradiction"
    assert len(verdict.tiered_findings) == 1

def test_audit_proposal_restrict_t2(audit_layer, event_bus_audit, mock_t2_checks, sample_proposal):
    mock_t2_checks.run_all.return_value = [
        TieredFinding(tier="T2", code="T2_InsufficientSample", explanation="Insufficient data")
    ]
    
    verdict = audit_layer.audit_proposal(sample_proposal)
    
    assert isinstance(verdict, AuditVerdict)
    assert verdict.action.type == "ALLOW_WITH_RESTRICTION"
    assert verdict.action.restrictions['max_order_size_pct'] == 0.25
    assert len(verdict.tiered_findings) == 1
