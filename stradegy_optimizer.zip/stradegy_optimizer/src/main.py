import yaml
import logging
import threading
import time
import os
from dotenv import load_dotenv

# Component Imports
from utils.logging_config import setup_logging
from utils.time_utils import TimeUtils
from utils.crypto_utils import CryptoUtils
from utils.statistical_tests import StatisticalTests
from storage.state_manager import StateManager
from storage.artifact_manager import ArtifactManager
from storage.replay_engine import ReplayEngine
from data_bus.event_bus import EventBus
from data_bus.market_data_bus import MarketDataBus
from execution.exchange_adapter import ExchangeAdapter
from processors.indicator_engine import IndicatorEngine
from processors.regime_classifier import RegimeClassifier
from optimizer.llm_interface import LLMInterface
from backtesting.position_manager import PositionManager
from backtesting.performance_metrics import PerformanceMetrics
from backtesting.backtest_engine import BacktestEngine
from optimizer.fallback_mode import FallbackMode
from optimizer.parameter_memory import ParameterMemory
from optimizer.signal_generator import SignalGenerator
from optimizer.strategy_optimizer import StrategyOptimizer
from audit.t1_checks import T1Checks
from audit.t2_checks import T2Checks
from audit.t3_checks import T3Checks
from audit.causal_chain_validator import CausalChainValidator as AuditCausalChainValidator
from audit.artifact_store import ArtifactStore
from audit.audit_layer import AuditLayer
from execution.order_manager import OrderManager
from execution.execution_engine import ExecutionEngine
from governance.incident_tracker import IncidentTracker
from governance.approval_workflow import ApprovalWorkflow
from governance.restriction_enforcer import RestrictionEnforcer
from governance.emergency_manager import EmergencyManager

def load_all_config(config_dir='config'):
    """Loads all YAML configuration files."""
    config = {}
    config_files = [
        os.path.join(config_dir, 'system_config.yaml'),
        os.path.join(config_dir, 'audit_rules.yaml'),
        os.path.join(config_dir, 'regime_config.yaml'),
        os.path.join(config_dir, 'parameter_bounds.yaml'),
        os.path.join(config_dir, 'safe_baseline.yaml')
    ]
    for file_path in config_files:
        with open(file_path, 'r') as f:
            config_key = os.path.basename(file_path).replace('.yaml', '')
            config[config_key] = yaml.safe_load(f)
    return config

def main():
    """
    Initializes all components and starts the main orchestration loops for
    the strategy optimizer and the audit layer.
    """
    # 1. Setup & Configuration
    setup_logging()
    load_dotenv()
    config = load_all_config()
    logging.info("Starting the Self-Auditing Strategy Optimizer...")

    # 2. Initialize all components with correct dependencies
    logging.info("Initializing components...")
    
    # Core Utilities
    state_manager = StateManager(config)
    crypto_utils = CryptoUtils()
    
    # Data & Execution Layer
    event_bus = EventBus(state_manager)
    exchange_adapter = ExchangeAdapter(config)
    market_data_bus = MarketDataBus(config, exchange_adapter)
    
    # Processors
    indicator_engine = IndicatorEngine(config, market_data_bus)
    regime_classifier = RegimeClassifier(config, indicator_engine)
    
    # Backtesting & Performance
    position_manager = PositionManager(config)
    performance_metrics = PerformanceMetrics(config)
    backtest_engine = BacktestEngine(config, None, position_manager, performance_metrics) # SignalGenerator injected later
    
    # Optimizer Components
    llm_interface = LLMInterface(config)
    fallback_mode = FallbackMode(config, backtest_engine)
    parameter_memory = ParameterMemory(state_manager)
    signal_generator = SignalGenerator(config, indicator_engine, regime_classifier)
    backtest_engine.signal_generator = signal_generator # Resolve circular dependency
    
    strategy_optimizer = StrategyOptimizer(config, regime_classifier, llm_interface, fallback_mode, parameter_memory, event_bus)

    # Audit Layer
    artifact_manager = ArtifactManager(config, crypto_utils)
    t1_checks = T1Checks(config)
    t2_checks = T2Checks(config)
    t3_checks = T3Checks(config)
    audit_causal_validator = AuditCausalChainValidator(config, artifact_manager)
    artifact_store = ArtifactStore(config, artifact_manager, crypto_utils)
    audit_layer = AuditLayer(config, event_bus, t1_checks, t2_checks, t3_checks, audit_causal_validator, artifact_store)
    
    # Execution & Governance
    order_manager = OrderManager(config, exchange_adapter, state_manager)
    execution_engine = ExecutionEngine(config, order_manager)
    incident_tracker = IncidentTracker(config, state_manager)
    approval_workflow = ApprovalWorkflow(config, state_manager)
    restriction_enforcer = RestrictionEnforcer(config)
    emergency_manager = EmergencyManager(config, incident_tracker, approval_workflow)
    
    logging.info("All components initialized.")

    # 3. Start background services in separate threads
    
    # Start AuditLayer listener in a background thread
    audit_thread = threading.Thread(target=audit_layer.listen_for_proposals, daemon=True)
    audit_thread.start()
    logging.info("Audit layer started in a background thread.")
    
    # HealthChecker and Dashboard could also be run in threads if desired
    # health_checker = HealthChecker(...)
    # health_thread = threading.Thread(target=health_checker.start_periodic_checks, daemon=True)
    # health_thread.start()

    # 4. Main orchestration loop
    try:
        while True:
            logging.info("Main loop iteration started.")
            
            # In a real system, this data would be fetched from a monitoring system or state manager
            current_metrics = {'max_drawdown_pct': 5.0, 'profit_factor': 1.2, 'trades_sample': 200} 
            
            symbol = 'BTC/USDT'
            start_date = '2023-01-01T00:00:00Z'
            end_date = '2023-01-31T23:59:59Z'
            regime, confidence = regime_classifier.classify_latest(symbol, start_date, end_date)

            # a. Generate a new proposal
            proposal = strategy_optimizer.propose_parameters(current_metrics, regime, {}, symbol, end_date)
            
            # b. Wait for the audit verdict from the event bus
            logging.info(f"Waiting for audit verdict for proposal {proposal.proposal_id}...")
            verdict = None
            for _ in range(30): # Wait for 30 seconds
                verdict = event_bus.subscribe_verdict(proposal.proposal_id)
                if verdict:
                    break
                time.sleep(1)

            if not verdict:
                logging.error(f"Timeout: No audit verdict received for proposal {proposal.proposal_id}. Triggering emergency.")
                emergency_manager.trigger_emergency("AUDIT_TIMEOUT", f"No verdict for proposal {proposal.proposal_id}")
                continue

            # c. Acknowledge proposal was handled
            event_bus.acknowledge_proposal(proposal.proposal_id)

            # d. Act on the verdict
            if verdict.action.type == "BLOCK":
                logging.warning(f"Execution BLOCKED for proposal {proposal.proposal_id}. Reason: {verdict.action.restrictions}")
                if any(f.tier == "T1" for f in verdict.tiered_findings):
                    t1_finding = next(f for f in verdict.tiered_findings if f.tier == "T1")
                    emergency_manager.trigger_emergency(t1_finding.code, t1_finding.explanation, proposal.proposal_id)
            
            elif verdict.action.type in ["ALLOW", "ALLOW_WITH_RESTRICTION"]:
                restriction_enforcer.apply_restrictions(verdict)
                # In a real system, a signal would be generated and passed to the execution engine
                # For now, we simulate this.
                mock_signal = {"symbol": "BTC/USDT", "signal": 1, "amount": 0.01}
                execution_engine.execute_trade(mock_signal, proposal.model_dump(), verdict.model_dump())
            
            # Wait before starting the next cycle
            logging.info("Main loop iteration finished. Waiting for next cycle...")
            time.sleep(60) # Run every 60 seconds

    except KeyboardInterrupt:
        logging.info("Shutting down Strategy Optimizer...")
    finally:
        logging.info("Strategy Optimizer has been shut down.")

if __name__ == "__main__":
    main()